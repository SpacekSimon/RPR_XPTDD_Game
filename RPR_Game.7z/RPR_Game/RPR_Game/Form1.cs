﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.SymbolStore;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPR_Game
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Hrac kokot = new Hrac("Filipek",0,2,0);
        NPC kono = new NPC("Onger", 1);
        NPC Jozo = new NPC("Simik", 1, 5);
        private void Form1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void panel1_Click(object sender, EventArgs e)
        {
            kokot.ZmenaPozice(e);
            label2.Text = kokot.ToString();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            kokot.PridejXP(int.Parse(textBox1.Text));
            label2.Text = kokot.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            kokot.Specializace = textBox2.Text;
            label2.Text = kokot.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Jozo.ZmenaPozice();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Jozo.ToString());
        }
    }
}
