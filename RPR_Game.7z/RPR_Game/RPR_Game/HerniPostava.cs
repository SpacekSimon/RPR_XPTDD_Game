﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPR_Game
{
    internal class HerniPostava
    {
        public string jmeno;
        public int level = 1;
        public double x = 0;
        public double y = 0;

        public string Jmeno{
            get { return this.jmeno; }
            set {
                if (value.Length < 10 && value != "")
                {
                    this.jmeno = value; 
                }
                else
                {
                    this.jmeno = "";
                    MessageBox.Show("Chybne napsane jmeno");
                }
            }
        }

        public double PoziceX
        {
            get { return this.x; }
        }
        public double PoziceY
        {
            get { return this.y; }
        }

        public HerniPostava(string jmeno)
        {
            Jmeno = jmeno;
        }

        public void ZmenaPozice(EventArgs e)
        {
            MouseEventArgs e2 = (MouseEventArgs)e;
            this.x= e2.X;
            this.y= e2.Y;
        }

        public override string ToString()
        {
            return "Jmeno: " + this.jmeno + " level: " + this.level + " pozice x: " + this.x + " pozice y: "+ this.y;
        }

    }
}
