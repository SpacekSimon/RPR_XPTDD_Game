﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPR_Game
{
    internal class Hrac : HerniPostava
    {
        private obliceje oblicej = 0;
        private vlasky vlasy = 0;
        private barvaVlasku barvaVlasu = 0;
        private string specializace;
        public int xp = 0;

        enum obliceje
        {
            velkynos, 
            usoplesk, 
            makeup,
        }
        enum vlasky
        {
            drdol,
            culik,
            dlouhe,
        }
        enum barvaVlasku
        {
            kastanova,
            blond,
            cervena,
        }

        public string Specializace
        {
            get { return this.specializace; }
            set {
                if (value == "Kouzelnik" || value == "Berserk" || value == "Inzenyr" || value == "Cizak")
                {
                    this.specializace = value;
                }
                else
                {
                    MessageBox.Show("Zadej platnou specializaci");
                }
            }
        }

        public Hrac(string jmeno, int typObliceje, int typVlasu, int barvaVlasu) : base(jmeno)
        {
            this.oblicej = (obliceje)typObliceje;
            this.vlasy = (vlasky)typVlasu;
            this.barvaVlasu = (barvaVlasku)barvaVlasu;
        }

        public void PridejXP(int mnozstviXP)
        {
            if (mnozstviXP > 0)
            {
                this.xp += mnozstviXP;
                while (this.xp >= 100 * this.level)
                {
                    this.xp -= 100 * this.level;
                    this.level++;
                }
            }
        }


        public override string ToString()
        {
            return "Specializace: " + this.specializace+
                "\nJmeno: " + this.jmeno + 
                "\nOblicej: " + this.oblicej +
                "\nTyp vlasu: " + this.vlasy+
                "\nBarva vlasu: " + this.barvaVlasu+
                "\nXP: " + this.xp+
                "\nLevel: " + this.level + 
                "\nPozice x: " + this.x + 
                "\nPozice y: " + this.y;
        }
    }
}
