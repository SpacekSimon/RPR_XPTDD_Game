﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPR_Game
{
    internal class NPC : HerniPostava
    {
        public typPrace prace = 0;
        public int sila = 0;

        public enum typPrace
        {
            obchodnik,
            nepritel,
            obyvatel,
        }


        public NPC(string jmeno, int typPrace):base(jmeno)
        {
            this.prace = (typPrace)typPrace;
            



        }
        public NPC(string jmeno, int typPrace,int sila) : base(jmeno)
        {
            this.prace = (typPrace)typPrace;
            this.sila = sila;



        }
        public void ZmenaPozice()
        {
            this.x = 379;
            this.y = 115;
        }
        public override string ToString()
        {
            if (sila > 0)
            {
                return " Jsem boss " + this.jmeno + " pracuji jako " + this.prace + " a mam silu " + this.sila + " a jsem na pozici " + this.x + " x a " + this.y + " y";
            }
            return " Jsem " + this.jmeno + " pracuji jako " + this.prace + " a mam silu " + this.sila + " a jsem na pozici " + this.x+" x a "+this.y+" y";

        }


    }
}
