﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPR_Game
{
    internal class NPC : HerniPostava
    {
        public typPrace prace = 0;
        public int sila = 0;

        public enum typPrace
        {
            obchodnik,
            nepritel,
            obyvatel,
        }


        public NPC(string jmeno, int typPrace):base(jmeno)
        {
            this.prace = (typPrace)typPrace;
        }
        public NPC(string jmeno, int typPrace,int sila) : base(jmeno)
        {
            this.prace = (typPrace)typPrace;
            if (sila > 0)
            {
                this.sila = sila;
            }
        }
        public void ZmenaPozice(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public override string ToString()
        {
            if (sila > 0)
            {
                return " Jsem boss " + this.jmeno + ", " + this.prace + " a mam silu " + this.sila + " a jsem na pozici " + this.x + " x a " + this.y + " y" + " a muj level je: "+this.level;
            }
            return " Jsem " + this.jmeno + ", " + this.prace + " a jsem na pozici " + this.x+" x a "+this.y+" y" + " a muj level je: " + this.level;

        }


    }
}
