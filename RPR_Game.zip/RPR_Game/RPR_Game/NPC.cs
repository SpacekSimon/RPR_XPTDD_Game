﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPR_Game
{
    internal class NPC : HerniPostava
    {
        public typPrace prace = 0;
        public int sila = 0;

        public enum typPrace
        {
            obchodnik,
            nepritel,
            obyvatel,
        }


        public NPC(string jmeno, int typPrace):base(jmeno)
        {
            this.prace = (typPrace)typPrace;
        }
        public NPC(string jmeno, int typPrace,int sila) : base(jmeno)
        {
            this.prace = (typPrace)typPrace;
            if (sila > 0)
            {
                this.sila = sila;
            }
        }
        public void ZmenaPozice(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public override string ToString()
        {
            if (sila > 0)
            {
                return "Typ: BOSS" +
                    "\nJmeno: " +this.jmeno + 
                    "\nTyp prace:" + this.prace +
                    "\nSila: " + this.sila +
                    "\nPozice x: " + this.x +
                    "\nPozice y: " + this.y +
                    "\nLevel je: " + this.level;
            }
            return "Typ: NPC" +
                    "\nJmeno: " + this.jmeno +
                    "\nTyp prace:" + this.prace +
                    "\nPozice x: " + this.x +
                    "\nPozice y: " + this.y +
                    "\nLevel je: " + this.level;

        }


    }
}
