﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;
using System.Security.Cryptography;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodLVLPOS()
        {
            // level nove postavy je 1
            HerniPostava marecek = new HerniPostava();
            Assert.AreEqual(marecek.LVL,1);
        }
        [TestMethod]
        public void TestMethodJmenoPOS()
        {
            // ověření zda jméno je kratší 10 znaků
            HerniPostava vitecek = new HerniPostava("MareVit");
            vitecek.jmeno = "xdddddddddddddddddddddd";

            Assert.IsTrue(vitecek.jmeno.Length <= 10 && vitecek.jmeno.Length > 0);
        }
        [TestMethod]
        public void TestMethodPoziceXSetTo0()
        {
            // ověření zda je počáteční pozice X nastavena na 0
            HerniPostava jk = new HerniPostava();

            Assert.AreEqual(jk.PosX, 0);
        }
        [TestMethod]
        public void TestMethodZdedenyAtributy()
        {
            // :3
            // >_<
            // >:3
            Hrac biktooor = new Hrac();

            // ověření zdědění atributů
            Assert.AreSame(biktooor.LVL, 0);
            Assert.IsTrue(biktooor.jmeno.Length <= 10);
            Assert.AreEqual(biktooor.PosX, 0);
        }
        [TestMethod]
        public void TestMethodSpecializace() 
        {
            Hrac biktooor = new Hrac("Hrac1", "Kouzelnik");

            biktooor.Specializace = "InvalidSpecialization";

            Assert.AreEqual("Kouzelnik", biktooor.Specializace);
        }
        [TestMethod]
        public void TestMethodOvereniXP0() 
        {
            Hrac viktor = new Hrac();

            Assert.AreEqual(viktor.XP, 0);
        }
        [TestMethod]
        public void TestMethodMaOblicej()
        {
            Hrac viktor = new Hrac();

            Assert.AreNotEqual(viktor.Oblicej, 0);
        }
        [TestMethod]
        public void TestMethodZdedenyAtributyHP()
        {
            NPC jk = new NPC();

            // ověření zdědění atributů
            Assert.AreSame(jk.LVL, 0);
            Assert.IsTrue(jk.jmeno.Length <= 10);
            Assert.AreEqual(jk.PosX, 0);
        }
        [TestMethod]
        public void TestMethodVytvInstaTridy()
        {
            NPC npc = new NPC("Obyvatel1", Prace.Obyvatel);

            Assert.IsNotNull(npc);
            Assert.AreEqual("Obyvatel1", npc.Jmeno);
            Assert.AreEqual(Prace.Obyvatel, npc.Prace);
            Assert.AreEqual(0,npc.Sila);
        }
        [TestMethod]
        public void TestMethodNPCToString()
        {
            NPC npc = new NPC("Obchodnik1", Prace.Obchodnik, 50);

            string expected = "Jmeno: Obchodnik1, Level: 1, Pozice X: 0, Pozice Y: 0, Prace: Obchodnik, Sila: 50";

            Assert.AreEqual(expected, npc.ToString());
        }
    }
}
