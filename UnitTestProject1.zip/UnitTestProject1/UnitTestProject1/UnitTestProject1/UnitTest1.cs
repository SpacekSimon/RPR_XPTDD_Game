﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Runtime.Remoting.Messaging;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]

        //BDD = chováním řízený vývoj
        //TDD = testování řízen projekt
        public void POsObsahujeSlovoRPR()
        {
            string heslo = "houbRPR";
            Assert.IsTrue(OvereniHesla.ObsahujeSlovoRPR(heslo));

        }

        [TestMethod]
        public void NEgObsahujeSlovoRPR()
        {
            string heslo = "koulABobek";
            Assert.IsTrue(OvereniHesla.ObsahujeSlovoRPR(heslo));
        }

        [TestMethod]

        public void POsVelikostHesla()
        {
            string heslo = "koulABobek";
            Assert.IsTrue(OvereniHesla.DelkaHesla(heslo));
        }

        [TestMethod]

        public void NEgVelikostHesla()
        {
            string heslo = "koul";
            Assert.IsTrue(OvereniHesla.DelkaHesla(heslo));
        }

        [TestMethod]

        public void POsPrazdneHeslo()
        {
            string heslo = "jupijahej";
            Assert.IsTrue(OvereniHesla.NeprazdneHeslo(heslo));
        }

        [TestMethod]

        public void NEgPrazdneHeslo()
        {
            string heslo = "";
            Assert.IsTrue(OvereniHesla.NeprazdneHeslo(heslo));
        }
    }
}
